import { spawn, type ChildProcess } from 'child_process'

export const SIGNAL_NUMBERS: Record<string, number> = {
  SIGHUP: 1,
  SIGINT: 2,
  SIGQUIT: 3,
  SIGILL: 4,
  SIGTRAP: 5,
  SIGABRT: 6,
  SIGBUS: 7,
  SIGFPE: 8,
  SIGKILL: 9,
  SIGSEGV: 11,
  SIGTERM: 15
}

export function spawnShell(command: string, cwd: string): ChildProcess {
  if (process.platform === 'win32') {
    const comSpec = process.env.ComSpec ?? process.env.COMSPEC ?? 'cmd.exe'
    return spawn(comSpec, ['/c', command], { cwd, windowsHide: true })
  }
  return spawn('/bin/sh', ['-c', command], { cwd })
}

export function pyNewlines(text: string): string {
  return text.replace(/\r\n?/gu, '\n')
}

export function shellReturncode(code: number | null, signal: string | null): number {
  return code === null ? -(SIGNAL_NUMBERS[signal ?? ''] ?? 1) : code
}
