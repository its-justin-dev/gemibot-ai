import { dialog, BrowserWindow } from 'electron'
import { readFile } from 'fs/promises'
import type { FileContents } from '../../shared/types/file'
import { log } from './logger.service'

const MAX_PREVIEW_BYTES = 64 * 1024

export const fileService = {
  async openTextFile(window: BrowserWindow): Promise<string | null> {
    const { canceled, filePaths } = await dialog.showOpenDialog(window, {
      title: 'Open a text file',
      properties: ['openFile'],
      filters: [
        { name: 'Text', extensions: ['txt', 'md', 'json', 'csv', 'log'] },
        { name: 'All files', extensions: ['*'] }
      ]
    })
    return canceled || filePaths.length === 0 ? null : filePaths[0]
  },

  async readText(filePath: string): Promise<FileContents | null> {
    try {
      const buffer = await readFile(filePath)
      const truncated = buffer.length > MAX_PREVIEW_BYTES
      return {
        path: filePath,
        text: buffer.subarray(0, MAX_PREVIEW_BYTES).toString('utf-8'),
        truncated
      }
    } catch (error) {
      log.error(`Failed to read ${filePath}`, error)
      return null
    }
  }
}
