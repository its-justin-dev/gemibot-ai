import { ToolError } from '../../shared/utils/exceptions'
import { pyPathPartsFull } from '../../shared/utils/py-path'
import { pyLstripChars, pyStrip, pyStripChars } from '../../shared/utils/pystr'
import { pyIsAbsolute, pyResolve, toPosix } from '../utils/fs-path'
import { win32 } from 'path'

export class AgentPaths {
  root: string

  constructor(root: string) {
    this.root = pyResolve(root)
  }

  setRoot(root: string): void {
    this.root = pyResolve(root)
  }

  isWithinTarget(candidatePath: string): boolean {
    try {
      const cand = pyPathPartsFull(pyResolve(candidatePath)).map((part) => part.toLowerCase())
      const targ = pyPathPartsFull(this.root).map((part) => part.toLowerCase())
      if (cand.length < targ.length) return false
      return targ.every((part, index) => part === cand[index])
    } catch {
      return false
    }
  }

  async resolve(path: string | null | undefined): Promise<string> {
    const rawPath = pyStripChars(pyStrip(String(path || '.')), '\'"')
    const cleaned = pyLstripChars(rawPath, '/\\')

    const candidate = pyIsAbsolute(rawPath) ? pyResolve(rawPath) : pyResolve(rawPath, this.root)
    if (this.isWithinTarget(candidate)) return candidate

    const full = pyResolve(cleaned, this.root)
    if (this.isWithinTarget(full)) return full

    throw new ToolError(
      `Access denied: Path '${path}' escapes the active target directory.\n` +
        `Active target directory: ${this.root}\n` +
        'All operations must remain strictly inside the target folder.'
    )
  }

  rel(fullPath: string): string {
    try {
      const fullP = pyResolve(fullPath)
      if (this.isWithinTarget(fullP)) return toPosix(win32.relative(this.root, fullP)) || '.'
      return fullP
    } catch {
      return String(fullPath)
    }
  }
}
