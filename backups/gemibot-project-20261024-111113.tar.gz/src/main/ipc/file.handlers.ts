import { ipcMain, BrowserWindow } from 'electron'
import { IPC } from '../../shared/constants/ipc-channels'
import { fileService } from '../services/file.service'

export function registerFileHandlers(): void {
  ipcMain.handle(IPC.FILE.OPEN_DIALOG, async (event) => {
    const window = BrowserWindow.fromWebContents(event.sender)
    if (!window) return null
    return fileService.openTextFile(window)
  })

  ipcMain.handle(IPC.FILE.READ_TEXT, (_event, filePath: unknown) => {
    if (typeof filePath !== 'string' || filePath.length === 0) return null
    return fileService.readText(filePath)
  })
}
