import { describe, expect, it, vi } from 'vitest'

vi.mock('electron', () => ({
  BrowserWindow: class {},
  app: { getPath: () => '' },
  clipboard: { writeText: () => undefined },
  dialog: {},
  ipcMain: { handle: () => undefined, on: () => undefined },
  shell: { openPath: async () => '' }
}))

import { WindowBridge } from '../../src/main/ipc/window.handlers'

/**
 * A reopened window replaces the renderer, but a dialog the runtime asked the old renderer for
 * can never be answered. `attachWindow` has to fail those asks so the waiting turn unwinds
 * instead of hanging forever.
 */

interface FakeWindow {
  received: unknown[]
  webContents: { send: (channel: string, event: unknown) => void }
  isDestroyed: () => boolean
}

function fakeWindow(): FakeWindow {
  const win: FakeWindow = {
    received: [],
    webContents: { send: (_channel, event) => win.received.push(event) },
    isDestroyed: () => false
  }
  return win
}

const runtime = { snapshot: () => ({}) } as never

async function flush(): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, 0))
}

describe('WindowBridge.attachWindow', () => {
  it('fails a read-line the old renderer was showing', async () => {
    const bridge = new WindowBridge()
    bridge.bindRuntime(runtime)
    const oldWin = fakeWindow()
    bridge.attachWindow(oldWin as never)

    const line = bridge.readLine('Name?')
    await flush()
    expect(oldWin.received).toEqual([{ kind: 'read-line', prompt: 'Name?', id: 1 }])

    bridge.attachWindow(fakeWindow() as never)
    await expect(line).resolves.toBeNull()
  })

  it('fails a permission dialog the old renderer was showing', async () => {
    const bridge = new WindowBridge()
    bridge.bindRuntime(runtime)
    const oldWin = fakeWindow()
    bridge.attachWindow(oldWin as never)

    const permission = bridge.permission('write_file', 'a.txt')
    await flush()
    expect(oldWin.received).toHaveLength(1)

    bridge.attachWindow(fakeWindow() as never)
    await expect(permission).resolves.toBe(false)
  })
})
